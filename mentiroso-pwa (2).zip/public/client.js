const socket = io();
const startBtn = document.getElementById("startBtn");
const statusDiv = document.getElementById("status");
const playersList = document.getElementById("players");

startBtn.addEventListener("click", () => {
  socket.emit("startRound");
});

socket.on("players", (players) => {
  playersList.innerHTML = "";
  players.forEach(p => {
    const li = document.createElement("li");
    li.textContent = `${p.id} - Puntos: ${p.score}`;
    if (p.id !== socket.id) {
      const truthBtn = document.createElement("button");
      truthBtn.textContent = "Verdad";
      truthBtn.onclick = () => socket.emit("vote", { target: p.id, vote: "truth" });

      const lieBtn = document.createElement("button");
      lieBtn.textContent = "Mentira";
      lieBtn.onclick = () => socket.emit("vote", { target: p.id, vote: "lie" });

      li.appendChild(truthBtn);
      li.appendChild(lieBtn);
    }
    playersList.appendChild(li);
  });
});

socket.on("newRound", ({ narrator }) => {
  statusDiv.textContent = `El narrador es: ${narrator}`;
});

socket.on("narrator", ({ truthMode }) => {
  statusDiv.textContent = truthMode
    ? "Dices la VERDAD esta ronda ✅"
    : "Tienes que MENTIR esta ronda ❌";
});
