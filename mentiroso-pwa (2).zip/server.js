
// Mentiroso PWA Game - Node.js + Socket.IO
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, "public")));

let players = {};
let narrator = null;
let truthMode = true;

io.on("connection", (socket) => {
  console.log("Jugador conectado:", socket.id);

  players[socket.id] = { id: socket.id, score: 0 };

  io.emit("players", Object.values(players));

  socket.on("disconnect", () => {
    delete players[socket.id];
    if (narrator === socket.id) narrator = null;
    io.emit("players", Object.values(players));
  });

  socket.on("startRound", () => {
    const ids = Object.keys(players);
    narrator = ids[Math.floor(Math.random() * ids.length)];
    truthMode = Math.random() < 0.5;

    io.to(narrator).emit("narrator", { truthMode });
    io.emit("newRound", { narrator });
  });

  socket.on("vote", ({ target, vote }) => {
    if (narrator && target === narrator) {
      if ((vote === "truth" && truthMode) || (vote === "lie" && !truthMode)) {
        players[socket.id].score += 1;
      } else {
        players[socket.id].score -= 1;
      }
      io.emit("players", Object.values(players));
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Servidor corriendo en http://localhost:${PORT}`));
